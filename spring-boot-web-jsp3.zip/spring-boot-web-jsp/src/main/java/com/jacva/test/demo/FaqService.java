package com.jacva.test.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class FaqService {

	public List<Faq> fetchAllFAQs() {
		List<Faq> faqs = new ArrayList<Faq>();
		faqs.add(new Faq("What is the concept of Bigg Boss? ", " Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur\n" + 
				"              gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non."));
		faqs.add(new Faq("What is in28Minutes", "Learn Spring Boot"));
		faqs.add(new Faq("What is in28Minutes", "Learn Hibernate"));
		return faqs;
	}
	
}