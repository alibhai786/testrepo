package com.jacva.test.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class FaqController {

	@Autowired
	FaqService service;

	@RequestMapping(value = "/faqs", method = RequestMethod.GET)
	public String showTodos(ModelMap model) {	
		List<Faq> faqsList = service.fetchAllFAQs();
		model.addAllAttributes(faqsList);
		return "faqs";
	}
}
