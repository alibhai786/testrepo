package com.jacva.test.demo;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		User user = new User("274", "421", "1,364", "18");
		model.put("user", user);
		return "home";
	}

}