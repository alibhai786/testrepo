package com.jacva.test.demo;

public class User {

	private String vendors;
	private String products;
	private String conferences;
	private String interactions;

	public User() {
	}

	public User(String vendors, String products, String conferences, String interactions) {
		super();
		this.vendors = vendors;
		this.products = products;
		this.conferences = conferences;
		this.interactions = interactions;
	}

	public String getVendors() {
		return vendors;
	}

	public void setVendors(String vendors) {
		this.vendors = vendors;
	}

	public String getProducts() {
		return products;
	}

	public void setProducts(String products) {
		this.products = products;
	}

	public String getConferences() {
		return conferences;
	}

	public void setConferences(String conferences) {
		this.conferences = conferences;
	}

	public String getInteractions() {
		return interactions;
	}

	public void setInteractions(String interactions) {
		this.interactions = interactions;
	}

}
