package com.jacva.test.demo;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

public class Xyz {

	public static void main(String args[]) throws InvalidPasswordException, IOException {
		readPDF(new File("E:\\GmailText.pdf"));
	}

	private static String readPDF(File pdf) throws InvalidPasswordException, IOException {
		try (PDDocument document = PDDocument.load(pdf)) {

			document.getClass();

			if (!document.isEncrypted()) {

				PDFTextStripperByArea stripper = new PDFTextStripperByArea();
				stripper.setSortByPosition(true);

				PDFTextStripper tStripper = new PDFTextStripper();

				String pdfFileInText = tStripper.getText(document);
				// System.out.println("Text:" + st);

				// split by whitespace
				String lines[] = pdfFileInText.split("\\r?\\n");
				List<String> pdfLines = new ArrayList<>();
				StringBuilder sb = new StringBuilder();
				for (String line : lines) {
					System.out.println(line);
					pdfLines.add(line);
					sb.append(line + "\n");
				}
				return sb.toString();
			}

		}
		return null;
	}

}
